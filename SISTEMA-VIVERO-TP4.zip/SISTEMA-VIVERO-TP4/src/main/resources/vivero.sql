CREATE DATABASE IF NOT EXISTS vivero CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vivero;

CREATE TABLE IF NOT EXISTS productos (
 id INT PRIMARY KEY, nombre VARCHAR(100) NOT NULL, categoria VARCHAR(100) NOT NULL,
 precio_compra DECIMAL(12,2) NOT NULL, precio_venta_minor DECIMAL(12,2) NOT NULL,
 precio_venta_mayor DECIMAL(12,2) NOT NULL, stock_actual INT NOT NULL,
 stock_minimo INT NOT NULL, descuento DECIMAL(5,2) NOT NULL DEFAULT 0,
 CHECK (precio_compra >= 0 AND precio_venta_minor >= 0 AND precio_venta_mayor >= 0),
 CHECK (stock_actual >= 0 AND stock_minimo >= 0), CHECK (descuento BETWEEN 0 AND 100)
);
CREATE TABLE IF NOT EXISTS proveedores (
 id INT PRIMARY KEY, nombre VARCHAR(100) NOT NULL, telefono VARCHAR(40),
 email VARCHAR(120), tipo_producto VARCHAR(100) NOT NULL
);
CREATE TABLE IF NOT EXISTS compras (
 id INT PRIMARY KEY, proveedor_id INT NOT NULL, producto_id INT NOT NULL,
 fecha DATE NOT NULL, cantidad INT NOT NULL, precio_unitario DECIMAL(12,2) NOT NULL,
 CONSTRAINT fk_compra_proveedor FOREIGN KEY (proveedor_id) REFERENCES proveedores(id),
 CONSTRAINT fk_compra_producto FOREIGN KEY (producto_id) REFERENCES productos(id),
 CHECK (cantidad > 0 AND precio_unitario >= 0)
);
CREATE TABLE IF NOT EXISTS ventas (
 id INT PRIMARY KEY, fecha DATE NOT NULL, tipo_venta VARCHAR(40) NOT NULL,
 total DECIMAL(12,2) NOT NULL
);
CREATE TABLE IF NOT EXISTS detalle_ventas (
 venta_id INT NOT NULL, producto_id INT NOT NULL, cantidad INT NOT NULL,
 precio_unitario DECIMAL(12,2) NOT NULL,
 PRIMARY KEY (venta_id, producto_id),
 CONSTRAINT fk_detalle_venta FOREIGN KEY (venta_id) REFERENCES ventas(id),
 CONSTRAINT fk_detalle_producto FOREIGN KEY (producto_id) REFERENCES productos(id),
 CHECK (cantidad > 0 AND precio_unitario >= 0)
);
