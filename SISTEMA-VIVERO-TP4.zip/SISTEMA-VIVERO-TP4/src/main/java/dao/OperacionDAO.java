package dao;
import Clases.*; import java.sql.*; import java.time.LocalDate; import java.util.*;
/** Registra compras y ventas con transacciones: stock y comprobante se confirman juntos. */
public class OperacionDAO {
 public void registrarCompra(Compra x)throws SQLException{
  String ins="INSERT INTO compras(id,proveedor_id,producto_id,fecha,cantidad,precio_unitario) VALUES(?,?,?,?,?,?)";
  try(Connection c=Conexion.obtener()){c.setAutoCommit(false);try{
   try(PreparedStatement s=c.prepareStatement("UPDATE productos SET stock_actual=stock_actual+? WHERE id=?")){s.setInt(1,x.cantidad());s.setInt(2,x.producto().getId());if(s.executeUpdate()!=1)throw new SQLException("Producto inexistente.");}
   try(PreparedStatement s=c.prepareStatement(ins)){s.setInt(1,x.id());s.setInt(2,x.proveedor().getId());s.setInt(3,x.producto().getId());s.setDate(4,java.sql.Date.valueOf(x.fecha()));s.setInt(5,x.cantidad());s.setDouble(6,x.precioUnitario());s.executeUpdate();}
   c.commit();
  }catch(Exception e){c.rollback();if(e instanceof SQLException se)throw se;throw new SQLException(e);}}
 }
 public void registrarVenta(Venta v)throws SQLException{
  if(v.getDetalles().isEmpty())throw new IllegalArgumentException("La venta no tiene detalles.");
  try(Connection c=Conexion.obtener()){c.setAutoCommit(false);try{
   try(PreparedStatement s=c.prepareStatement("INSERT INTO ventas VALUES(?,?,?,?)")){s.setInt(1,v.getId());s.setDate(2,java.sql.Date.valueOf(v.getFecha()));s.setString(3,v.getTipoVenta());s.setDouble(4,v.calcularTotal());s.executeUpdate();}
   for(detalleVenta d:v.getDetalles()){
    try(PreparedStatement s=c.prepareStatement("UPDATE productos SET stock_actual=stock_actual-? WHERE id=? AND stock_actual>=?")){s.setInt(1,d.cantidad());s.setInt(2,d.producto().getId());s.setInt(3,d.cantidad());if(s.executeUpdate()!=1)throw new SQLException("Stock insuficiente o producto inexistente: "+d.producto().getNombre());}
    try(PreparedStatement s=c.prepareStatement("INSERT INTO detalle_ventas VALUES(?,?,?,?)")){s.setInt(1,v.getId());s.setInt(2,d.producto().getId());s.setInt(3,d.cantidad());s.setDouble(4,d.precioUnitario());s.executeUpdate();}
   } c.commit();
  }catch(Exception e){c.rollback();if(e instanceof SQLException se)throw se;throw new SQLException(e);}}
 }
 public List<String> listarCompras()throws SQLException{List<String> l=new ArrayList<>();String q="SELECT c.id,c.fecha,p.nombre producto,pr.nombre proveedor,c.cantidad,c.precio_unitario FROM compras c JOIN productos p ON p.id=c.producto_id JOIN proveedores pr ON pr.id=c.proveedor_id ORDER BY c.fecha DESC,c.id DESC";
  try(Connection c=Conexion.obtener();PreparedStatement s=c.prepareStatement(q);ResultSet r=s.executeQuery()){while(r.next())l.add(String.format("Compra %d | %s | %s | proveedor %s | %d unidades | total $%.2f",r.getInt(1),r.getDate(2),r.getString(3),r.getString(4),r.getInt(5),r.getInt(5)*r.getDouble(6)));}return l;}
 public List<String> listarVentas()throws SQLException{List<String> l=new ArrayList<>();try(Connection c=Conexion.obtener();PreparedStatement s=c.prepareStatement("SELECT id,fecha,tipo_venta,total FROM ventas ORDER BY fecha DESC,id DESC");ResultSet r=s.executeQuery()){while(r.next())l.add(String.format("Venta %d | %s | %s | total $%.2f",r.getInt(1),r.getDate(2),r.getString(3),r.getDouble(4)));}return l;}
 public int proximoId(String tabla)throws SQLException{if(!Set.of("compras","ventas").contains(tabla))throw new IllegalArgumentException("Tabla no permitida.");try(Connection c=Conexion.obtener();Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT COALESCE(MAX(id),0)+1 FROM "+tabla)){r.next();return r.getInt(1);}}
}
