package dao;
import java.sql.Connection; import java.sql.DriverManager; import java.sql.SQLException;
/** Fabrica de conexiones; permite configurar credenciales sin modificar el código. */
public final class Conexion {
 private Conexion(){}
 public static Connection obtener() throws SQLException {
  String url=System.getenv().getOrDefault("VIVERO_DB_URL","jdbc:mysql://localhost:3306/vivero?serverTimezone=UTC&useSSL=false");
  String user=System.getenv().getOrDefault("VIVERO_DB_USER","root");
  String pass=System.getenv().getOrDefault("VIVERO_DB_PASSWORD","");
  return DriverManager.getConnection(url,user,pass);
 }
}
