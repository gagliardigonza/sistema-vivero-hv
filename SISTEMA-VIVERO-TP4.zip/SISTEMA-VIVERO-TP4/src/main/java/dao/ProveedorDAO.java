package dao;
import Clases.Proveedor; import java.sql.*; import java.util.*;
public class ProveedorDAO {
 public void guardar(Proveedor x)throws SQLException{String q="INSERT INTO proveedores VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE nombre=VALUES(nombre),telefono=VALUES(telefono),email=VALUES(email),tipo_producto=VALUES(tipo_producto)";
  try(Connection c=Conexion.obtener();PreparedStatement p=c.prepareStatement(q)){p.setInt(1,x.getId());p.setString(2,x.getNombre());p.setString(3,x.getTelefono());p.setString(4,x.getEmail());p.setString(5,x.getTipoProducto());p.executeUpdate();}}
 public List<Proveedor> listar()throws SQLException{List<Proveedor> l=new ArrayList<>();try(Connection c=Conexion.obtener();PreparedStatement p=c.prepareStatement("SELECT * FROM proveedores ORDER BY id");ResultSet r=p.executeQuery()){while(r.next())l.add(new Proveedor(r.getInt("id"),r.getString("nombre"),r.getString("telefono"),r.getString("email"),r.getString("tipo_producto")));}return l;}
 public Optional<Proveedor> buscar(int id)throws SQLException{try(Connection c=Conexion.obtener();PreparedStatement p=c.prepareStatement("SELECT * FROM proveedores WHERE id=?")){p.setInt(1,id);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(new Proveedor(r.getInt("id"),r.getString("nombre"),r.getString("telefono"),r.getString("email"),r.getString("tipo_producto"))):Optional.empty();}}}
}
