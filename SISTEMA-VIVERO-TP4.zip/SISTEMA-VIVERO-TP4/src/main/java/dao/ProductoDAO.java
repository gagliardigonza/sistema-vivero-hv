package dao;
import Clases.Producto; import java.sql.*; import java.util.*;
public class ProductoDAO {
 public List<Producto> listar() throws SQLException { List<Producto> out=new ArrayList<>();
  String q="SELECT * FROM productos ORDER BY id";
  try(Connection c=Conexion.obtener();PreparedStatement p=c.prepareStatement(q);ResultSet r=p.executeQuery()){
   while(r.next())out.add(map(r));
  } return out;
 }
 public Optional<Producto> buscar(int id)throws SQLException{
  try(Connection c=Conexion.obtener();PreparedStatement p=c.prepareStatement("SELECT * FROM productos WHERE id=?")){
   p.setInt(1,id);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(map(r)):Optional.empty();}
  }
 }
 private Producto map(ResultSet r)throws SQLException{return new Producto(r.getInt("id"),r.getString("nombre"),r.getString("categoria"),r.getDouble("precio_compra"),r.getDouble("precio_venta_minor"),r.getDouble("precio_venta_mayor"),r.getInt("stock_actual"),r.getInt("stock_minimo"),r.getDouble("descuento"));}
 public void guardar(Producto x)throws SQLException{
  String q="INSERT INTO productos VALUES(?,?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE nombre=VALUES(nombre),categoria=VALUES(categoria),precio_compra=VALUES(precio_compra),precio_venta_minor=VALUES(precio_venta_minor),precio_venta_mayor=VALUES(precio_venta_mayor),stock_actual=VALUES(stock_actual),stock_minimo=VALUES(stock_minimo),descuento=VALUES(descuento)";
  try(Connection c=Conexion.obtener();PreparedStatement p=c.prepareStatement(q)){p.setInt(1,x.getId());p.setString(2,x.getNombre());p.setString(3,x.getTipoCategoria());p.setDouble(4,x.getPrecioCompra());p.setDouble(5,x.getPrecioVentaMinor());p.setDouble(6,x.getPrecioVentaMayor());p.setInt(7,x.getStockActual());p.setInt(8,x.getStockMinimo());p.setDouble(9,x.getDescuento());p.executeUpdate();}
 }
 public void eliminar(int id)throws SQLException{try(Connection c=Conexion.obtener();PreparedStatement p=c.prepareStatement("DELETE FROM productos WHERE id=?")){p.setInt(1,id);p.executeUpdate();}}
}
