package Clases;
public class Producto extends Articulo {
    private String tipoCategoria; private double precioCompra, precioVentaMinor, precioVentaMayor, descuento;
    private int stockActual, stockMinimo;
    public Producto(int id,String nombre,String categoria,double compra,double minor,double mayor,int stock,int minimo,double descuento){
        super(id,nombre); setTipoCategoria(categoria); setPrecioCompra(compra); setPrecioVentaMinor(minor); setPrecioVentaMayor(mayor);
        setStockActual(stock); setStockMinimo(minimo); setDescuento(descuento);
    }
    public String obtenerDescripcionTipo(){ return tipoCategoria; }
    public String getTipoCategoria(){return tipoCategoria;}
    public void setTipoCategoria(String v){if(v==null||v.isBlank())throw new IllegalArgumentException("Categoría obligatoria.");tipoCategoria=v.trim();}
    public double getPrecioCompra(){return precioCompra;} public void setPrecioCompra(double v){precioCompra=precioValido(v);}
    public double getPrecioVentaMinor(){return precioVentaMinor;} public void setPrecioVentaMinor(double v){precioVentaMinor=precioValido(v);}
    public double getPrecioVentaMayor(){return precioVentaMayor;} public void setPrecioVentaMayor(double v){precioVentaMayor=precioValido(v);}
    private double precioValido(double v){if(!Double.isFinite(v)||v<0)throw new IllegalArgumentException("Precio inválido.");return v;}
    public int getStockActual(){return stockActual;} public void setStockActual(int v){if(v<0)throw new IllegalArgumentException("Stock negativo.");stockActual=v;}
    public int getStockMinimo(){return stockMinimo;} public void setStockMinimo(int v){if(v<0)throw new IllegalArgumentException("Stock mínimo negativo.");stockMinimo=v;}
    public double getDescuento(){return descuento;} public void setDescuento(double v){if(v<0||v>100||!Double.isFinite(v))throw new IllegalArgumentException("Descuento entre 0 y 100.");descuento=v;}
    public void aumentarStock(int c){if(c<=0)throw new IllegalArgumentException("Cantidad positiva requerida.");stockActual+=c;}
    public void reducirStock(int c){if(c<=0||c>stockActual)throw new IllegalArgumentException("Cantidad inválida o stock insuficiente.");stockActual-=c;}
    public boolean necesitaReposicion(){return stockActual<=stockMinimo;}
}
