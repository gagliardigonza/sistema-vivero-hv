package Clases;
import java.time.LocalDate;
public record Compra(int id, Proveedor proveedor, Producto producto, int cantidad, double precioUnitario, LocalDate fecha) {
    public Compra { if(id<=0||proveedor==null||producto==null||cantidad<=0||precioUnitario<0||fecha==null) throw new IllegalArgumentException("Compra inválida."); }
    public double calcularTotal(){return cantidad*precioUnitario;}
}
