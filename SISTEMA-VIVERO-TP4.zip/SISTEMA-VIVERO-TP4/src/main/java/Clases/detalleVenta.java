package Clases;
public record detalleVenta(Producto producto,int cantidad,double precioUnitario) {
    public detalleVenta { if(producto==null||cantidad<=0||precioUnitario<0)throw new IllegalArgumentException("Detalle inválido."); }
    public double calcularSubtotal(){return cantidad*precioUnitario;}
}
