package Clases;
public class Planta extends Producto {
    private String temporada, cuidados;
    public Planta(int id,String nombre,String categoria,double compra,double minor,double mayor,int stock,int minimo,double desc,String temporada,String cuidados){
        super(id,nombre,categoria,compra,minor,mayor,stock,minimo,desc);
        this.temporada=temporada==null?"No especificada":temporada; this.cuidados=cuidados==null?"No especificados":cuidados;
    }
    public String getTemporada(){return temporada;} public String getCuidados(){return cuidados;}
    @Override public String obtenerDescripcionTipo(){return "Planta - "+getTipoCategoria();}
}
