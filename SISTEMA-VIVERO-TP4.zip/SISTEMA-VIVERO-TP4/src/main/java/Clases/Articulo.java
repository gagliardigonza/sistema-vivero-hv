package Clases;
/** Abstracción de los artículos comercializados por el vivero. */
public abstract class Articulo {
    private int id; private String nombre;
    protected Articulo(int id, String nombre) { setId(id); setNombre(nombre); }
    public int getId(){ return id; }
    public void setId(int id){ if(id<=0) throw new IllegalArgumentException("El ID debe ser positivo."); this.id=id; }
    public String getNombre(){ return nombre; }
    public void setNombre(String n){ if(n==null||n.isBlank()) throw new IllegalArgumentException("El nombre es obligatorio."); nombre=n.trim(); }
    public abstract String obtenerDescripcionTipo();
}
