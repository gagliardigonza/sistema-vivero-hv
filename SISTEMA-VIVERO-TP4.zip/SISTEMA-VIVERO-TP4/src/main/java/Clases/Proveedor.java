package Clases;
public class Proveedor {
    private int id; private String nombre,telefono,email,tipoProducto;
    public Proveedor(int id,String nombre,String telefono,String email,String tipo){
        if(id<=0)throw new IllegalArgumentException("ID positivo requerido.");this.id=id;
        this.nombre=req(nombre);this.telefono=telefono==null?"":telefono;this.email=email==null?"":email;this.tipoProducto=req(tipo);
    }
    private String req(String s){if(s==null||s.isBlank())throw new IllegalArgumentException("Dato obligatorio.");return s.trim();}
    public int getId(){return id;} public String getNombre(){return nombre;} public String getTelefono(){return telefono;}
    public String getEmail(){return email;} public String getTipoProducto(){return tipoProducto;}
}
