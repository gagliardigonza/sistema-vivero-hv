package Clases;
import java.time.LocalDate; import java.util.ArrayList; import java.util.List;
public class Venta {
    private final int id; private final LocalDate fecha; private final String tipoVenta; private final ArrayList<detalleVenta> detalles=new ArrayList<>();
    public Venta(int id,LocalDate fecha,String tipo){if(id<=0||fecha==null||tipo==null||tipo.isBlank())throw new IllegalArgumentException("Venta inválida.");this.id=id;this.fecha=fecha;this.tipoVenta=tipo;}
    public int getId(){return id;} public LocalDate getFecha(){return fecha;} public String getTipoVenta(){return tipoVenta;}
    public void agregarDetalle(detalleVenta d){if(d==null)throw new IllegalArgumentException("Detalle nulo.");detalles.add(d);}
    public List<detalleVenta> getDetalles(){return List.copyOf(detalles);}
    public double calcularTotal(){return detalles.stream().mapToDouble(detalleVenta::calcularSubtotal).sum();}
}
