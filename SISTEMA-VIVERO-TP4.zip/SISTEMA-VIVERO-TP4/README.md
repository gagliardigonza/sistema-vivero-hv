# Sistema de Gestión – Vivero Hiper Verde San José (TP4)

Proyecto Java 17 + Maven + MySQL. Aplicación de consola para administrar productos, proveedores, compras, ventas y existencias.

## Requisitos
- JDK 17 o superior.
- Apache Maven 3.8+.
- MySQL 8.0+.
- IntelliJ IDEA (u otra IDE Java).

## Instalación
1. Abrir MySQL Workbench y ejecutar `src/main/resources/vivero.sql`.
2. Configurar conexión mediante variables de entorno:
   - `VIVERO_DB_URL=jdbc:mysql://localhost:3306/vivero?serverTimezone=UTC&useSSL=false`
   - `VIVERO_DB_USER=root` (o el usuario creado)
   - `VIVERO_DB_PASSWORD=tu_clave`
3. Abrir la carpeta como proyecto Maven y esperar la descarga de dependencias.
4. Ejecutar `mvn clean compile`.
5. Ejecutar `mvn exec:java`.

## Funcionalidades
- Alta, listado, búsqueda, modificación y eliminación de productos.
- Consulta de productos que necesitan reposición.
- Alta y listado de proveedores.
- Registro y consulta de compras; la compra aumenta el stock.
- Registro y consulta de ventas minoristas/mayoristas; la venta descuenta stock.
- Las compras y ventas se registran mediante transacciones JDBC. Si una operación falla, se revierte para evitar inconsistencias.

## Arquitectura y patrón
- `Clases`: entidades del dominio y reglas básicas.
- `dao`: acceso a datos JDBC con `PreparedStatement`.
- `OperacionDAO`: transacciones de compras y ventas.
- `Main`: interacción por consola.
- Patrón DAO: separa la lógica de persistencia de la interfaz y del modelo.

## Estructuras y POO
- `Articulo` es abstracta; `Producto` hereda de ella y `Planta` especializa `Producto`.
- `String[]` representa las opciones fijas del menú.
- `ArrayList` se utiliza para recuperar y trabajar con colecciones de productos, proveedores y detalles de venta.
- Se aplican encapsulamiento, herencia, abstracción y polimorfismo.

## Pruebas manuales recomendadas
1. Crear producto con stock inicial 10.
2. Crear proveedor.
3. Registrar compra de 5 unidades y verificar stock 15.
4. Registrar venta minorista de 3 unidades y verificar stock 12.
5. Intentar vender más unidades que las disponibles: la operación debe fallar y no registrar una venta parcial.
6. Cerrar y volver a abrir la aplicación: los registros deben permanecer en MySQL.

## Limitaciones del prototipo
La interfaz es de consola. La clase `Planta` permite modelar datos particulares, pero el esquema actual conserva los atributos comunes de producto; temporada y cuidados pueden incorporarse en una iteración posterior mediante columnas específicas. Los IDs de comprobantes se calculan a partir del máximo existente; para un uso concurrente real conviene migrar a `AUTO_INCREMENT` o una secuencia controlada.

## Publicación en GitHub
Crear un repositorio propio y subir el contenido de esta carpeta. No publicar contraseñas ni datos reales de acceso.
